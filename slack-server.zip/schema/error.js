export default `
  type Error {
    path: String!
    message: String
  }
`;
