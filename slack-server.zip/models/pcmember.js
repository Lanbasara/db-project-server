export default (sequelize) => {
  const PCMember = sequelize.define('pcmember', {});

  return PCMember;
};
