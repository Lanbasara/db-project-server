import { PubSub } from 'graphql-subscriptions';

export default new PubSub();
